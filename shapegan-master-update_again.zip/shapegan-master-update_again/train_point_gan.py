import os.path as osp

import os
import numpy as np
import sys

import argparse
import torch
from torch.utils.data import DataLoader
from torch.optim import RMSprop

from datasets import PointDataset
from model.point_sdf_net import PointNet, SDFGenerator
from model.embeddings import VADLogVar

parser = argparse.ArgumentParser()
parser.add_argument('--category', type=str, required=True)
args = parser.parse_args()

LATENT_SIZE = 128
GRADIENT_PENALITY = 10
HIDDEN_SIZE = 256
NUM_LAYERS = 8
NORM = True

device = 'cuda' if torch.cuda.is_available() else 'cpu'
G = SDFGenerator(LATENT_SIZE, HIDDEN_SIZE, NUM_LAYERS, NORM, dropout=0.0)
D = PointNet(out_channels=1)
G, D = G.to(device), D.to(device)
G_optimizer = RMSprop(G.parameters(), lr=0.0001)
D_optimizer = RMSprop(D.parameters(), lr=0.0001)

root = osp.join(f'data/{args.category}')
dataset = PointDataset.from_split(root, split='test')

configuration = [  # num_points, batch_size, epochs
    (1024, 32, 300),
    (2048, 32, 300),
    (4096, 32, 300),
    (8192, 24, 300),
    (16384, 12, 300),
    (32768, 6, 900),
]

num_steps = 0
####################自己改的代码####################
def KLD(mu,logvar):
    KLD = -0.5*torch.sum(1+logvar-mu.pow(2)-logvar.exp(),dim=-1)
    KLD=torch.mean(KLD)
    return KLD

test_shape_ids=[]
with open('./data/chairs/test.txt','r') as f:
    for line in f:
        lines = line.strip('\n')
        test_shape_ids.append(lines)
# print(len(test_shape_ids))
N = len(test_shape_ids)
latent_embeddings = VADLogVar(N,LATENT_SIZE)
VAD_optimizer = torch.optim.Adam(latent_embeddings.parameters(),lr=0.0001,betas=(0.9,0.999),weight_decay=0)

def _b_idx2latent(self, latent_embeddings, indices,
                  num_augment_pts=None):  # 实例化的latent_embeddings 需要传入idx得到latent_codes
    batch_latent_dict = latent_embeddings(indices, num_augment_pts=num_augment_pts)  # 这一步其实是embedding.py的前向传递
    batch_latent = batch_latent_dict['latent_code']  # 这里开始后面就是取出对应的部分
    if 'mu' in batch_latent_dict.keys() and 'logvar' in batch_latent_dict.keys():
        batch_mu = batch_latent_dict['mu']
        batch_logvar = batch_latent_dict['logvar']
        kld = KLD(batch_mu, batch_logvar)
        self.additional_log_info['vad_batch_mu_std'] = torch.std(batch_mu).item()  #######vad的dict  std
        self.additional_log_info['vad_batch_kld'] = kld.item()
        if 'std' in batch_latent_dict.keys():
            batch_sigma = batch_latent_dict['std']
        else:
            batch_sigma = torch.exp(0.5 * batch_logvar)
        self.additional_log_info['vad_batch_sigma_mean'] = torch.mean(batch_sigma).item()  #######vad的dict  std
    else:
        kld = 0.0

    if 'latent_code_augment' in batch_latent_dict.keys():
        batch_latent_aug = batch_latent_dict['latent_code_augment']
    else:
        batch_latent_aug = batch_latent
    return batch_latent, batch_latent_aug, kld

##################################################
for num_points, batch_size, epochs in configuration:
    dataset.num_points = num_points
    loader = DataLoader(dataset, batch_size, shuffle=True, num_workers=6)

    for epoch in range(1, epochs + 1):
        total_loss = 0
        for idx, file_name, uniform, _ in loader:
            data_indices = idx.squeeze(-1).to(device,non_blocking=True)
            mu, logvar, batch_latent = latent_embeddings(data_indices)
            batch_latent=batch_latent.to(device)
            print(len(batch_latent))
            kld = KLD(mu, logvar)
            # print(data_indices)
            # print(file_name)
            # if file_name[0] in test_shape_ids:
            #     print(file_name[0])
            # print(file_name[0])
            # print(len(uniform))
            # print(uniform[0].size(0))
            num_steps += 1

            # print(uniform[0])

            uniform = uniform.to(device)
            u_pos, u_dist = uniform[..., :3], uniform[..., 3:]
            print(u_pos[0])

            D_optimizer.zero_grad()
            VAD_optimizer.zero_grad()

            # z = torch.randn(uniform.size(0), LATENT_SIZE, device=device)
            # fake = G(u_pos, z)
            fake = G(u_pos, batch_latent)
            out_real = D(u_pos, u_dist)
            out_fake = D(u_pos, fake)
            D_loss = out_fake.mean() - out_real.mean()

            alpha = torch.rand((uniform.size(0), 1, 1), device=device)
            interpolated = alpha * u_dist + (1 - alpha) * fake
            interpolated.requires_grad_(True)
            out = D(u_pos, interpolated)

            grad = torch.autograd.grad(out, interpolated,
                                       grad_outputs=torch.ones_like(out),
                                       create_graph=True, retain_graph=True,
                                       only_inputs=True)[0]
            grad_norm = grad.view(grad.size(0), -1).norm(dim=-1, p=2)
            gp = GRADIENT_PENALITY * ((grad_norm - 1).pow(2).mean())

            loss = D_loss + gp
            loss.backward()
            D_optimizer.step()
            VAD_optimizer.step()

            if num_steps % 5 == 0:
                G_optimizer.zero_grad()
                z = torch.randn(uniform.size(0), LATENT_SIZE, device=device)
                fake = G(u_pos, z)
                out_fake = D(u_pos, fake)
                loss = -out_fake.mean()
                loss.backward()
                G_optimizer.step()

            total_loss += D_loss.abs().item()

        print('Num points: {}, Epoch: {:03d}, Loss: {:.6f}'.format(
            num_points, epoch, total_loss / len(loader)))
