import os
import numpy as np
import sys
result=[]
with open('./data/chairs/test.txt','r') as f:
    for line in f:
        lines = line.strip('\n')
        result.append(lines)
print(len(result))
# print(11)


# sphere_list=[]
# with os.scandir('./data/chairs/uniform') as npy_list:
#     print(22)
#     # print(len(npy_list))
#     for npy_path in npy_list:
#         if npy_path.is_file():
#             print(npy_path.path)
#             # print(npy_path.name)
#             # sphere_list.append(npy_path.name.split('.')[0])  ########也就是把文件名存在sphere_list里
#             if npy_path.name.split('.')[0] in result:
#                 print(33)
#                 test_path = os.path.join('/data/chairs/test_data,npy_path.name')
# # print(sphere_list)
# test_path = os.path.join('./data/chairs/test_data,1a6f615e8b1b5ae4dbbc9440457e303e.npy')
# data=np.load(test_path)
# print(data)

def _b_idx2latent(self, latent_embeddings, indices,
                  num_augment_pts=None):  # 实例化的latent_embeddings 需要传入idx得到latent_codes
    batch_latent_dict = latent_embeddings(indices, num_augment_pts=num_augment_pts)  # 这一步其实是embedding.py的前向传递
    batch_latent = batch_latent_dict['latent_code']  # 这里开始后面就是取出对应的部分
    if 'mu' in batch_latent_dict.keys() and 'logvar' in batch_latent_dict.keys():
        batch_mu = batch_latent_dict['mu']
        batch_logvar = batch_latent_dict['logvar']
        kld = KLD(batch_mu, batch_logvar)
        self.additional_log_info['vad_batch_mu_std'] = torch.std(batch_mu).item()  #######vad的dict  std
        self.additional_log_info['vad_batch_kld'] = kld.item()
        if 'std' in batch_latent_dict.keys():
            batch_sigma = batch_latent_dict['std']
        else:
            batch_sigma = torch.exp(0.5 * batch_logvar)
        self.additional_log_info['vad_batch_sigma_mean'] = torch.mean(batch_sigma).item()  #######vad的dict  std
    else:
        kld = 0.0

    if 'latent_code_augment' in batch_latent_dict.keys():
        batch_latent_aug = batch_latent_dict['latent_code_augment']
    else:
        batch_latent_aug = batch_latent
    return batch_latent, batch_latent_aug, kld




