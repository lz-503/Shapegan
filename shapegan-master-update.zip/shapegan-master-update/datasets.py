import torch
from torch.utils.data import Dataset
import os
import numpy as np


class VoxelDataset(Dataset):
    def __init__(self, files, clamp=0.1, rescale_sdf=True):
        self.files = files
        self.clamp = clamp
        self.rescale_sdf = rescale_sdf

    def __len__(self):
        # L = len(self.files)
        # print(L)
        return len(self.files)

    def __getitem__(self, index):
        # print(len(self.files))
        # print(self.files)
        name = self.files[index]
        # print(name)

        shape_id = self.files[index].split('/')[3].split('.')[0]
        # print(shape_id)
        array = np.load(self.files[index])
        # shape_id, file=self.files[index]
        # print(shape_id,file)
        # array = np.load(file)
        # print(array.size(0))
        result = torch.from_numpy(array)
        if self.clamp is not None:
            # print(self.clamp)
            result.clamp_(-self.clamp, self.clamp)
            if self.rescale_sdf:
                result /= self.clamp
        result_new = (index, shape_id, result)
        return result_new

    @staticmethod
    def glob(pattern):
        import glob
        files = glob.glob(pattern, recursive=True)
        if len(files) == 0:
            raise Exception(
                'No files found for glob pattern {:s}.'.format(pattern))
        return VoxelDataset(sorted(files))

    @staticmethod
    def from_split(pattern, split_file_name):
        # train_data_list=[]
        split_file = open(split_file_name, 'r')
        ids = split_file.readlines()
        # ids=ids.strip('\n')
        # train_ids.append(ids)
        # print(train_ids)
        files = [pattern.format(id.strip()) for id in ids]
        files = [file for file in files if os.path.exists(file)]
        # # print(files[0].split('/')[3].split('.')[0])
        # for i in range(len(files)):
        #     train_data_list.append((files[i].split('/')[3].split('.')[0],files[i]))
        # print(train_data_list)
        return VoxelDataset(files)
        # return VoxelDataset(train_data_list)

    def show(self):
        from rendering import MeshRenderer
        import time
        from tqdm import tqdm

        viewer = MeshRenderer()
        for item in tqdm(self):
            viewer.set_voxels(item.numpy())
            time.sleep(0.5)
            # viewer.quit()


class PointDataset(Dataset):
    def __init__(self, root, filenames, num_points=1024, transform=None):
        self.root = os.path.expanduser(os.path.join(os.path.normpath(root)))
        self.filenames = filenames
        self.num_points = num_points
        assert 0 < self.num_points <= 64**3
        self.transform = transform

    def __len__(self):
        # L = len(self.filenames)
        # print(L)
        return len(self.filenames)

    def __getitem__(self, idx):
        name = self.filenames[idx]

        # print(name)
        uniform = os.path.join(self.root, 'uniform', f'{name}.npy')
        uniform = torch.from_numpy(np.load(uniform))

        surface = os.path.join(self.root, 'surface', f'{name}.npy')
        surface = torch.from_numpy(np.load(surface))

        # Sample a subset of points.
        sample = np.random.choice(uniform.size(0), self.num_points)
        uniform, surface = uniform[sample], surface[sample]

        idx_t = np.array([idx],dtype=np.long)

        data = (idx_t, name, uniform, surface)

        if self.transform is not None:
            data = self.transform(data)/OpenGL/arrays/vbo.py
        # print(data)
        # if name=='a8febf7ef6ce1d8cf7d0fb681a992ad6':
        #     print(uniform.size(0))

        return data

    @staticmethod
    def from_split(root, split, num_points=1024, transform=None):
        with open(os.path.join(root, f'{split}.txt'), 'r') as f:
            filenames = f.read().split('\n')
            if filenames[-1] == '':
                filenames = filenames[:-1]
        # print(filenames)
        sid2idx = {k:v for v,k in enumerate(sorted(filenames))}
        # print(sid2idx)
        # print(len(sid2idx))
        return PointDataset(root, filenames, num_points, transform)


if __name__ == '__main__':
    # dataset = VoxelDataset.glob('data/chairs/voxels_64/')
    # dataset = VoxelDataset.glob('data/chairs/voxels_32/**.npy')

    # dataset = VoxelDataset.from_split(
    #     'data/chairs/voxels_{:d}/{{:s}}.npy'.format(64),
    #     'data/chairs/test.txt')
    # dataset.__len__()
    # dataset.show()

    dataset = PointDataset.from_split('data/chairs', 'test')
    # for i in range(10):
    #     print(dataset.__getitem__(i))

    # dataset.__len__()