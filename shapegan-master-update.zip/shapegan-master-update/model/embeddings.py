import torch
import torch.nn as nn
import numpy as np
class VADLogVar(nn.Module):
    def __init__(self, N, dim):
        super(VADLogVar, self).__init__()
        self.N = N
        self.dim = dim
        self.weight_mu = nn.Parameter(torch.Tensor(N, dim))
        self.weight_logvar = nn.Parameter(torch.Tensor(N, dim))
        self.reset_parameters()
        self.num_embeddings = N
        self.embedding_dim = dim
        print('[VADLogVar Embedding] #entries: {}; #dims: {};'.format(self.N, self.dim))

    def reset_parameters(self):
        mu_init_std = 1.0 / np.sqrt(self.dim)
        torch.nn.init.normal_(
            self.weight_mu.data,
            0.0,
            mu_init_std,
        )
        logvar_init_std = 1.0 / np.sqrt(self.dim)
        torch.nn.init.normal_(
            self.weight_logvar.data,
            -4.0,
            logvar_init_std,
        )
    def forward(self, idx):
        mu = self.weight_mu[idx]
        logvar = self.weight_logvar[idx]
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        batch_latent = mu + eps * std
        return mu, logvar, batch_latent