import torch
from torch.nn import Linear, Sequential, ReLU, LayerNorm
import torch.nn.functional as F

import numpy as np
import skimage.measure
import trimesh

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# try:
from torch_scatter import scatter_max
# except ImportError:
#     scatter_max = None
######
import os
MODEL_PATH = "models"
CHECKPOINT_PATH = os.path.join(MODEL_PATH, 'checkpoints')
LATENT_CODES_FILENAME = os.path.join(MODEL_PATH, "sdf_net_latent_codes.to")
######
###############
from util import get_points_in_unit_sphere, get_voxel_coordinates
class SDFVoxelizationHelperData():
    def __init__(self, device, voxel_resolution, sphere_only=True):
        sample_points = get_voxel_coordinates(voxel_resolution)

        if sphere_only:
            unit_sphere_mask = np.linalg.norm(sample_points, axis=1) < 1.1
            sample_points = sample_points[unit_sphere_mask, :]
            self.unit_sphere_mask = unit_sphere_mask.reshape(voxel_resolution, voxel_resolution, voxel_resolution)

        self.sample_points = torch.tensor(sample_points, device=device)
        self.point_count = self.sample_points.shape[0]


sdf_voxelization_helper = dict()

SDF_NET_BREADTH = 256
###############




class PointNet(torch.nn.Module):
    def __init__(self, out_channels):
        super(PointNet, self).__init__()

        self.nn1 = Sequential(
            Linear(4, 64),
            ReLU(),
            Linear(64, 128),
            ReLU(),
            Linear(128, 256),
            ReLU(),
            Linear(256, 512),
        )

        self.nn2 = Sequential(
            Linear(512, 256),
            ReLU(),
            Linear(256, 128),
            ReLU(),
            Linear(128, out_channels),
        )

    def forward(self, pos, dist, batch=None):
        dist = dist.unsqueeze(-1) if dist.size(-1) != 1 else dist

        # print(pos.shape)
        # print(dist.shape)

        x = torch.cat([pos, dist], dim=-1)

        x = self.nn1(x)

        if batch is None:
            x = x.max(dim=-2)[0]
        else:
            x = scatter_max(x, batch, dim=-2)[0]

        x = self.nn2(x)

        return x


class SDFGenerator(torch.nn.Module):
    def __init__(self, latent_channels, hidden_channels, num_layers, norm=True,
                 dropout=0.0):
        super(SDFGenerator, self).__init__()
        self.filename = "G-point-generator.to" ####自己写的
        self.layers1 = None
        self.layers2 = None

        assert num_layers % 2 == 0

        self.latent_channels = latent_channels
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.norm = norm
        self.dropout = dropout

        in_channels = 3
        out_channels = hidden_channels

        self.lins = torch.nn.ModuleList()
        self.norms = torch.nn.ModuleList()
        for i in range(num_layers):
            # print(i,in_channels,out_channels)
            self.lins.append(Linear(in_channels, out_channels))
            self.norms.append(LayerNorm(out_channels))

            if i == (num_layers // 2) - 1:
                in_channels = hidden_channels + 3
            else:
                in_channels = hidden_channels

            if i == num_layers - 2:
                out_channels = 1

        self.z_lin1 = Linear(latent_channels, hidden_channels)
        self.z_lin2 = Linear(latent_channels, hidden_channels)

    def forward(self, pos, z):
        # pos: [batch_size, num_points, 3]
        # z: [batch_size, latent_channels]

        # print(pos.device)
        # print(z.device)

        # pos = pos.unsqueeze(0) if pos.dim() == 2 else pos
        # print("************")
        # print(pos.shape)
        # print(z.shape)
        # assert pos.dim() == 3
        assert pos.size(-1) == 3

        z = z.unsqueeze(0) if z.dim() == 1 else z
        assert z.dim() == 2
        assert z.size(-1) == self.latent_channels
        # print(pos.shape)
        # print(z.shape)
        # z=z[None,]
        # print(z.shape)
        # print(pos.size(0))
        # print(z.size(0))
        assert pos.size(0) == z.size(0)

        x = pos
        print("++++++")
        print(x.shape)
        print(z.shape)
        # print(pos.size(0))
        # print(z.size(0))
        for i, (lin, norm) in enumerate(zip(self.lins, self.norms)):
            print(i)
            if i == self.num_layers // 2: #4
                # print("************")
                # print(i)
                print(x.shape)
                print(pos.shape)
                x = torch.cat([x, pos], dim=-1)
                # print(x.shape)
            # print(x.device)
            x = lin(x)
            print(x.shape)
            if i == 0:
                print(self.z_lin1(z).unsqueeze(1).shape)
                print(x.shape)
                x = self.z_lin1(z) + x
                print("*****")
                print(x.shape)
            if i == self.num_layers // 2:
                x = self.z_lin2(z) + x
                print("!!!!!!!!!!!")
                print(x.shape)
            if i < self.num_layers - 1:
                x = norm(x) if self.norm else x
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)
                # print("&&&&&&&&&")
        print(x.shape)
        return x.squeeze()
###########自己改的
    def get_filename(self, epoch=None, filename=None):
        if filename is None:
            filename = self.filename
        if epoch is None:
            return os.path.join(MODEL_PATH, filename)
        else:
            filename = filename.split('.')
            filename[-2] += '-epoch-{:05d}'.format(epoch)
            filename = '.'.join(filename)
            return os.path.join(CHECKPOINT_PATH, filename)

    def load(self, epoch=None):
        self.load_state_dict(torch.load(self.get_filename(epoch=epoch)), strict=False)

    def save(self, epoch=None):
        if epoch is not None and not os.path.exists(CHECKPOINT_PATH):
            os.mkdir(CHECKPOINT_PATH)
        torch.save(self.state_dict(), self.get_filename(epoch=epoch))


##########包括以下部分##########
    def evaluate_in_batches(self, points, latent_code, batch_size=100000, return_cpu_tensor=True):
        latent_codes = latent_code.repeat(batch_size, 1)

        with torch.no_grad():
            batch_count = points.shape[0] // batch_size
            if return_cpu_tensor:
                result = torch.zeros((points.shape[0]))
            else:
                result = torch.zeros((points.shape[0]), device=points.device)
            print(points.shape[0])
            # print(latent_codes.shape[0])
            for i in range(batch_count):
                # print(i)
                # print(points[batch_size * i:batch_size * (i+1), :].device) # cuda:0
                # print(latent_codes.device)                                 # cuda:0
                # print(latent_codes.shape)
                # print(points[batch_size * i:batch_size * (i+1), :].shape)
                result[batch_size * i:batch_size * (i+1)] = self(points[batch_size * i:batch_size * (i+1), :], latent_codes)
                print(result)
            print(points.device)
            remainder = points.shape[0] - batch_size * batch_count
            result[batch_size * batch_count:] = self(points[batch_size * batch_count:, :], latent_codes[:remainder, :])
        return result

    def get_voxels(self, latent_code, voxel_resolution, sphere_only=True, pad=True):
        if not (voxel_resolution, sphere_only) in sdf_voxelization_helper:
            helper_data = SDFVoxelizationHelperData(self.device, voxel_resolution, sphere_only)
            sdf_voxelization_helper[(voxel_resolution, sphere_only)] = helper_data
        else:
            helper_data = sdf_voxelization_helper[(voxel_resolution, sphere_only)]

        with torch.no_grad():
            # data_helper = helper_data.sample_points.to(device)
            # print(helper_data.sample_points.to(device).device)
            # print(latent_code.device)
            # print("***********")
            distances = self.evaluate_in_batches(helper_data.sample_points.to(device), latent_code).numpy()

        if sphere_only:
            voxels = np.ones((voxel_resolution, voxel_resolution, voxel_resolution), dtype=np.float32)
            voxels[helper_data.unit_sphere_mask] = distances
        else:
            voxels = distances.reshape(voxel_resolution, voxel_resolution, voxel_resolution)
            if pad:
                voxels = np.pad(voxels, 1, mode='constant', constant_values=1)
        # print(voxels.device)
        return voxels

    def get_mesh(self, latent_code, voxel_resolution=64, sphere_only=True, raise_on_empty=False, level=0):
        size = 2
        # print(latent_code.device)
        voxels = self.get_voxels(latent_code, voxel_resolution=voxel_resolution, sphere_only=sphere_only)
        voxels = np.pad(voxels, 1, mode='constant', constant_values=1)
        try:
            vertices, faces, normals, _ = skimage.measure.marching_cubes(voxels, level=level, spacing=(
            size / voxel_resolution, size / voxel_resolution, size / voxel_resolution))
        except ValueError as value_error:
            if raise_on_empty:
                raise value_error
            else:
                return None

        vertices -= size / 2
        mesh = trimesh.Trimesh(vertices=vertices, faces=faces, vertex_normals=normals)
        return mesh

    def get_uniform_surface_points(self, latent_code, point_count=1000, voxel_resolution=64, sphere_only=True, level=0):
        mesh = self.get_mesh(latent_code, voxel_resolution=voxel_resolution, sphere_only=sphere_only, level=level)
        return mesh.sample(point_count)

    def get_normals(self, latent_code, points):
        if latent_code.requires_grad or points.requires_grad:
            raise Exception('get_normals may only be called with tensors that don\'t require grad.')

        points.requires_grad = True
        latent_codes = latent_code.repeat(points.shape[0], 1)
        sdf = self(points, latent_codes)
        sdf.backward(torch.ones(sdf.shape[0], device=self.device))
        normals = points.grad
        normals /= torch.norm(normals, dim=1).unsqueeze(dim=1)
        return normals

    def get_surface_points(self, latent_code, sample_size=100000, sdf_cutoff=0.1, return_normals=False,
                           use_unit_sphere=True):
        if use_unit_sphere:
            points = get_points_in_unit_sphere(n=sample_size, device=self.device) * 1.1
        else:
            points = torch.rand((sample_size, 3), device=self.device) * 2.2 - 1
        points.requires_grad = True
        latent_codes = latent_code.repeat(points.shape[0], 1)

        sdf = self(points, latent_codes)

        sdf.backward(torch.ones((sdf.shape[0]), device=self.device))
        normals = points.grad
        normals /= torch.norm(normals, dim=1).unsqueeze(dim=1)
        points.requires_grad = False

        # Move points towards surface by the amount given by the signed distance
        points -= normals * sdf.unsqueeze(dim=1)

        # Discard points with truncated SDF values
        mask = (torch.abs(sdf) < sdf_cutoff) & torch.all(torch.isfinite(points), dim=1)
        points = points[mask, :]
        normals = normals[mask, :]

        if return_normals:
            return points, normals
        else:
            return points

    def get_surface_points_in_batches(self, latent_code, amount=1000):
        result = torch.zeros((amount, 3), device=self.device)
        position = 0
        iteration_limit = 20
        while position < amount and iteration_limit > 0:
            points = self.get_surface_points(latent_code, sample_size=amount * 6)
            amount_used = min(amount - position, points.shape[0])
            result[position:position + amount_used, :] = points[:amount_used, :]
            position += amount_used
            iteration_limit -= 1
        return result

    @property
    def device(self):
        return next(self.parameters()).device