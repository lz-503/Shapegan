import torch
from torch.nn import Linear, Sequential, ReLU, LayerNorm
import torch.nn.functional as F
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# try:
from torch_scatter import scatter_max
# except ImportError:
#     scatter_max = None
######
import os
MODEL_PATH = "models"
CHECKPOINT_PATH = os.path.join(MODEL_PATH, 'checkpoints')
LATENT_CODES_FILENAME = os.path.join(MODEL_PATH, "sdf_net_latent_codes.to")
######

###############




class PointNet(torch.nn.Module):
    def __init__(self, out_channels):
        super(PointNet, self).__init__()

        self.nn1 = Sequential(
            Linear(4, 64),
            ReLU(),
            Linear(64, 128),
            ReLU(),
            Linear(128, 256),
            ReLU(),
            Linear(256, 512),
        )

        self.nn2 = Sequential(
            Linear(512, 256),
            ReLU(),
            Linear(256, 128),
            ReLU(),
            Linear(128, out_channels),
        )

    def forward(self, pos, dist, batch=None):
        dist = dist.unsqueeze(-1) if dist.size(-1) != 1 else dist

        # print(pos.shape)
        # print(dist.shape)

        x = torch.cat([pos, dist], dim=-1)

        x = self.nn1(x)

        if batch is None:
            x = x.max(dim=-2)[0]
        else:
            x = scatter_max(x, batch, dim=-2)[0]

        x = self.nn2(x)

        return x


class SDFGenerator(torch.nn.Module):
    def __init__(self, latent_channels, hidden_channels, num_layers, norm=True,
                 dropout=0.0):
        super(SDFGenerator, self).__init__()
        self.filename = "G-point-generator.to" ####自己写的
        self.layers1 = None
        self.layers2 = None

        assert num_layers % 2 == 0

        self.latent_channels = latent_channels
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.norm = norm
        self.dropout = dropout

        in_channels = 3
        out_channels = hidden_channels

        self.lins = torch.nn.ModuleList()
        self.norms = torch.nn.ModuleList()
        for i in range(num_layers):
            # print(i,in_channels,out_channels)
            self.lins.append(Linear(in_channels, out_channels))
            self.norms.append(LayerNorm(out_channels))

            if i == (num_layers // 2) - 1:
                in_channels = hidden_channels + 3
            else:
                in_channels = hidden_channels

            if i == num_layers - 2:
                out_channels = 1

        self.z_lin1 = Linear(latent_channels, hidden_channels)
        self.z_lin2 = Linear(latent_channels, hidden_channels)

    def forward(self, pos, z):
        # pos: [batch_size, num_points, 3]
        # z: [batch_size, latent_channels]

        # print(pos.device)
        # print(z.device)

        pos = pos.unsqueeze(0) if pos.dim() == 2 else pos

        assert pos.dim() == 3
        assert pos.size(-1) == 3

        z = z.unsqueeze(0) if z.dim() == 1 else z
        assert z.dim() == 2
        assert z.size(-1) == self.latent_channels
        # print(pos.shape)
        # print(z.shape)
        # z=z[None,]
        # print(z.shape)
        assert pos.size(0) == z.size(0)

        x = pos
        # print(pos.shape)
        # print(z.shape)
        for i, (lin, norm) in enumerate(zip(self.lins, self.norms)):
            if i == self.num_layers // 2:
                # print("************")
                # print(x.shape)
                # print(pos.shape)
                x = torch.cat([x, pos], dim=-1)
                # print(x.shape)
            # print(x.device)
            x = lin(x)

            if i == 0:
                x = self.z_lin1(z).unsqueeze(1) + x

            if i == self.num_layers // 2:
                x = self.z_lin2(z).unsqueeze(1) + x

            if i < self.num_layers - 1:
                x = norm(x) if self.norm else x
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)

        return x
###########自己改的
    def get_filename(self, epoch=None, filename=None):
        if filename is None:
            filename = self.filename
        if epoch is None:
            return os.path.join(MODEL_PATH, filename)
        else:
            filename = filename.split('.')
            filename[-2] += '-epoch-{:05d}'.format(epoch)
            filename = '.'.join(filename)
            return os.path.join(CHECKPOINT_PATH, filename)

    def load(self, epoch=None):
        self.load_state_dict(torch.load(self.get_filename(epoch=epoch)), strict=False)

    def save(self, epoch=None):
        if epoch is not None and not os.path.exists(CHECKPOINT_PATH):
            os.mkdir(CHECKPOINT_PATH)
        torch.save(self.state_dict(), self.get_filename(epoch=epoch))

    @property
    def device(self):
        return next(self.parameters()).device